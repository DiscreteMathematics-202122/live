import numpy as np

import matplotlib.pyplot as plt
import matplotlib.patches as patches
import matplotlib.patches as mpatches

style = "Simple, tail_width=0.5, head_width=8, head_length=12"
kw = dict(arrowstyle=style, color="k")


def is_relation(source, target, relation, silent=False):
  
    A, B, R = source, target, relation
    
    if type(A)!=set:
        if not silent: print(f"First argument (the souurce) must be a non-empty set, but found a {type(A)}")
        return False
    
    if len(A)==0:
        if not silent: print(f"First argument (the souurce) must be a non-empty set.")
        return False

    if type(B)!=set:
        if not silent: print(f"Second argument (the target) must be a non-empty set, but found a {type(B)}")
        return False
    if len(B)==0:
        if not silent: print(f"Second argument (the target) must be a non-empty set.")
        return False
    
    if type(R)!=set:
        if not silent: print(f"Third argument (the relation) must be a set, but found a {type(R)}")
        return False

    C = {(a,b) for a in A for b in B}
    if not R.issubset(C):
        if not silent: print(f"Third argument (the relation) must be a subset of the Cartessian product source x target")
        return False

    return True


def domain(source, target, relation):
    
    A, B, R = source, target, relation
    
    return {a for a,b in R}


def image(source, target, relation):
    
    A, B, R = source, target, relation
    
    return {b for a,b in R}


def is_injective(source, target, relation):
    
    A, B, R = source, target, relation

    if not is_relation(A,B,R): return 
    
    image = [ b for a,b in R]
    return len(set(image))==len(image)


def is_onto(source, target, relation):
    
    A, B, R = source, target, relation

    if not is_relation(A,B,R): return 
    
    image = [ b for a,b in R]
    return set(image)==len(target)


def describe_relation(source, target, relation):
    
    A, B, R = source, target, relation
    result = (f"Source: {source}\n" +
        f"Target: {target}\n" +
        f"Domain: {domain(A,B,R)}\n" +
        f"Image: {image(A,B,R)}"
        + "\nRelation is " + ("'onto' since image=target" if is_onto(A,B,R) else "'into' since image is proper subset of target")
        + "\nRelation is " + ("injective domain=source" if is_onto(A,B,R) else "not injective since domain is proper subset of source")
    )
    
    print(result)


def draw_relation(source, target, relation, describe=False, vpadding=0.4):
  
    A, B, R = source, target, relation
    
    if not is_relation(A,B,R): return 
        
    fig, ax = plt.subplots(figsize=(6, 6))

    def draw_set(A,source=True, vpadding=0.2, width=0.05):
        values = sorted(list(A))
        points = {}
        n = len(values)
        x = np.zeros(len(values)) + (0 if source else 0.4)
        y = np.arange(n) - n/2
        
        patch = mpatches.FancyBboxPatch([x[0]-width/2, y.min()-vpadding], width, y.max()-y.min()+3*vpadding, 
                color='#d0d0ff', boxstyle=mpatches.BoxStyle("Round4",  rounding_size=0.01, pad=0.02))
        ax.add_patch(patch)

        ax.scatter(x, y, zorder=2)
        for k, value in enumerate(values):
            label = f"{value} " if source else f" {value}"
            halign = "right" if source else "left"
            #ax.annotate(f"d{value}", (x[k],y[k]))
            ax.text(x[k], y[k], label, horizontalalignment=halign, verticalalignment='bottom', fontsize=15)
            points[value] = (x[k], y[k])

        return points, (y.min(), y.max())

    A_points, A_lim = draw_set(A,1)  
    B_points, B_lim = draw_set(B,0) 

    for a,b in R:
        link = patches.FancyArrowPatch(A_points[a], B_points[b], connectionstyle="arc3,rad=.1", **kw)
        plt.gca().add_patch(link)

    plt.ylim(min(A_lim[0],B_lim[0])-vpadding, max(A_lim[1],B_lim[1])+vpadding )
    plt.axis('off')
    # plt.savefig("relation.pdf", bbox_inches="tight")
    plt.show()
    
    if describe:
        describe_relation(A,B,R)

if __name__=="__main__":
    A = {1,3,5}
    B = {1,4,5}
    C = {(a,b) for a in A for b in B}
    R = {(a,b) for a in A for b in B if a>b}

    draw_relation(A, B, R)